# Staged kubeadm upgrade runbook

This package runs one minor at a time and one stage at a time.

## Add other masters

Put every control-plane node under `[kube_control_plane]`.
The first one is treated as the primary control plane and is upgraded by `upgrade_stage=first_master`.
The rest are upgraded by `upgrade_stage=other_masters`.

Example:

```ini
[kube_control_plane]
master-1 ansible_host=127.0.0.1 ansible_connection=local
master-2 ansible_host=172.16.106.50
master-3 ansible_host=172.16.106.51

[kube_workers]
worker-1 ansible_host=172.16.106.80
worker-2 ansible_host=172.16.106.81
```

## Run order per minor

For 1.31 -> 1.32:

```bash
ansible-playbook -i inventory.ini upgrade-k8s.yml -e 'target_minor=1.32' -e 'upgrade_stage=first_master'
ansible-playbook -i inventory.ini upgrade-k8s.yml -e 'target_minor=1.32' -e 'upgrade_stage=other_masters'
ansible-playbook -i inventory.ini upgrade-k8s.yml -e 'target_minor=1.32' -e 'upgrade_stage=workers'
ansible-playbook -i inventory.ini upgrade-k8s.yml -e 'target_minor=1.32' -e 'upgrade_stage=validate'
```

Then repeat for 1.33, 1.34, and so on.

## Important

- `first_master` requires all nodes to start on one version.
- `workers` and `other_masters` are allowed to run when the cluster is temporarily mixed-version after the first master is upgraded.
- `expected_starting_minor` is enforced only for the `first_master` stage.
