# Kubernetes HA Ansible - Root to Root SSH Edition

This package is the HA Kubernetes Ansible setup adapted for:
- Bastion run user: root
- Remote SSH user on all masters and workers: root
- Bastion IP used as stable kubeadm controlPlaneEndpoint
- HAProxy on Bastion for Kubernetes API load balancing

## Inventory groups
- bastion
- kube_control_plane
- kube_workers

## Run order
1. Prepare SSH key on Bastion root account
2. Copy root public key to all nodes
3. Verify root SSH access to all nodes
4. Run:
   - ansible-playbook -i inventory/production/hosts.ini playbooks/common.yml
   - ansible-playbook -i inventory/production/hosts.ini playbooks/master.yml
   - ansible-playbook -i inventory/production/hosts.ini playbooks/worker.yml

## Full run
ansible-playbook -i inventory/production/hosts.ini site.yml
